﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectSerialization
{
    [Serializable()]
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Address CustomerAddress { get; set; }

        [System.Xml.Serialization.XmlIgnoreAttribute()]
        [NonSerialized()]
        public List<string> BrowseHistory;
    }

    [Serializable()]
    public class Address
    {
        public string City { get; set; }
        public string Appartment { get; set; }
        public string Country { get; set; }
        public string Pincode { get; set; }
    }
}
