﻿// See https://aka.ms/new-console-template for more information
using ObjectSerialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.Json;
using System.Xml.Serialization;

Console.WriteLine("Hello, World!");

Customer Meena = new Customer()
{
    Id = 1001,
    Name = "Meena",
    BrowseHistory = new List<string>() { "https://google.com", "https://amazon.co.in" },
    CustomerAddress = new Address() { City = "Bangalore", Appartment = "Sumadhura", Country = "India", Pincode = "562107" }
};
Directory.CreateDirectory(@"F:\Serialized");
WatchFile();
FileStream fs = File.Create(@"F:\Serialized\SerializedCustomer.xml");
XmlSerializer xSerializer = new XmlSerializer(typeof(Customer));
xSerializer.Serialize(fs,Meena);
fs.Close();
Customer xMeena = (Customer)xSerializer.Deserialize(File.Open(@"F:\Serialized\SerializedCustomer.xml", FileMode.Open));
Print(xMeena, "Xml Serialization");

FileStream fbs = File.Create(@"F:\Serialized\SerializedCustomer.bin");
BinaryFormatter binaryFormatter = new BinaryFormatter();
binaryFormatter.Serialize(fbs, Meena);
fbs.Close();
Customer bMeena = (Customer)binaryFormatter.Deserialize(File.Open(@"F:\Serialized\SerializedCustomer.bin", FileMode.Open));
Print(bMeena, "Binary Serialization");

string strMeena = JsonSerializer.Serialize(Meena);
Customer jMeena = JsonSerializer.Deserialize<Customer>(strMeena);
Print(jMeena, "JSON Serialization");

static void Print(Customer c, string title)
{
    Console.WriteLine($"######### {title} ##########");
    Console.WriteLine($"Name: {c.Name} \n Id:{c.Id} \n\t " +
        $"Browsing History: {c.BrowseHistory?.Count??0}\n\t" +
        $"Address\n\t\t City: {c.CustomerAddress.City}" +
        $"\n\t\t Country: {c.CustomerAddress.Country}" +
        $"\n\t\t Appartment: {c.CustomerAddress.Appartment}" +
        $"\n\t\t Pincode : {c.CustomerAddress.Pincode}");
}

static void WatchFile()
{
    using var watcher = new FileSystemWatcher(@"F:\Serialized\");

    watcher.NotifyFilter = NotifyFilters.Attributes
                         | NotifyFilters.CreationTime
                         | NotifyFilters.DirectoryName
                         | NotifyFilters.FileName
                         | NotifyFilters.LastAccess
                         | NotifyFilters.LastWrite
                         | NotifyFilters.Security
                         | NotifyFilters.Size;

    watcher.Changed += Watcher_Changed; //(object sender, FileSystemEventArgs e) => { Console.WriteLine($"File change detected in {e.FullPath}"); };
    watcher.Created += Watcher_Created; //(object sender, FileSystemEventArgs e) => { Console.WriteLine($"File creation at {e.FullPath}"); };
    watcher.Deleted += Watcher_Deleted; //(object sender, FileSystemEventArgs e) => { Console.WriteLine($"File deleted at {e.FullPath}"); };
    watcher.Filter = "*.txt";
    watcher.IncludeSubdirectories = true;
    watcher.EnableRaisingEvents = true;
    string filepath = @"F:\Serialized\Simple.txt";
    File.Create(filepath).Close();
    File.WriteAllText(filepath, "Adding new text to this file.");
    File.Delete(filepath);

    Console.WriteLine("Press enter to exit.");
    Console.ReadLine();
}

static void Watcher_Deleted(object sender, FileSystemEventArgs e)
{
    Console.WriteLine($"File deleted at {e.FullPath}");
}

static void Watcher_Created(object sender, FileSystemEventArgs e)
{
    Console.WriteLine($"File creation at {e.FullPath}");
}

static void Watcher_Changed(object sender, FileSystemEventArgs e)
{
    Console.WriteLine($"File change detected in {e.FullPath}");
}