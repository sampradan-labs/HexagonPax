﻿// See https://aka.ms/new-console-template for more information
using System.Collections.Concurrent;

UseConcurrentBag();
ParallelLoop();
static async void UseConcurrentBag()
{

    ConcurrentBag<Task> taskBag = new ConcurrentBag<Task>();
    Task t1 = new Task(() => Method1());
    Task t2 = new Task(() => Method2());

    taskBag.Add(t1);
    taskBag.Add(t2);

    foreach (var t in taskBag)
    {
        t.Start();
        Console.WriteLine($"Id: {t.Id}, Status: {t.Status}, IsCancellable: {t.IsCanceled}");
    }
}

static async Task Method1()
{
    await Task.Run(() =>
    {
        for (int i = 0; i < 1000; i++)
        {
            Console.WriteLine($"M1-{i} Method 1");
        }
    });

}

static void Method2()
{
    for (int i = 0; i < 25; i++)
    {
        Console.WriteLine($"M2-{i} Method 2");
    }
}

static void ParallelLoop()
{
    List<int> ints = new List<int>() { 1, 2, 3, 4, 5 };
    List<int> longerInts = Enumerable.Range(1, 1000).ToList();  //Creating a list enumerating from 1--1000
    Parallel.ForEach(longerInts, (item) => {
        Console.WriteLine($"Parallel Execution {item} - {Thread.CurrentThread.ManagedThreadId}");
    });

    //Parallel.ForEach(longerInts, (singleInt) =>
    //{
    //    Console.WriteLine($"Parallel Printing {singleInt}");
    //});
}