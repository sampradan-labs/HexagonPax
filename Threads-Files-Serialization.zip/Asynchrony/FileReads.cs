﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asynchrony
{
    internal class FileReads
    {
        public async static Task DoFileOperations()
        {
            string folderName = @"F:\SampleFolder";
            string filename = "sample.txt";
            await CreateFile(filename, folderName);

            string contents = @$"{DateTime.Now.Date}-{DateTime.Now.TimeOfDay}-{DateTime.Now.DayOfWeek}: 
                                    Folder created: {folderName}, FileCreated: {filename}.
                                    This is a log file and contains the actions taken on the mentioned file";
            await WriteToFile(@$"{folderName}\{filename}", contents);
            await ReadFile(@$"{folderName}\{filename}");

        }

        private static async Task ReadFile(string filePath)
        {
            await File.ReadAllTextAsync(filePath);
            StringBuilder readLog = new StringBuilder();
            readLog.Append(DateTime.Now.Date);
            readLog.Append(" : ");
            readLog.Append(DateTime.Now.Kind);
            readLog.Append(" - A File read operation has occurred. This file will be accessible upto ");
            readLog.Append(DateTime.Now.Date.AddDays(30));
            readLog.Append(" days.");
            await WriteToFile(filePath, readLog.ToString());
        }

        private static async Task WriteToFile(string filePath, string contents)
        {
            await File.AppendAllTextAsync(filePath, contents);
        }

        private static async Task CreateFile(string filename, string folderPath)
        {
            DirectoryInfo folder = Directory.CreateDirectory(folderPath);
            FileStream fs = await Task.Run(()=>File.Create(@$"{folder.FullName}\{filename}"));
            fs.Close();
        }

    }
}
