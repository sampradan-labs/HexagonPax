﻿// See https://aka.ms/new-console-template for more information
using Asynchrony;

Console.WriteLine("Hello, World!");
//SimpleThread();
//M1M2();
await FileReads.DoFileOperations();
Console.WriteLine(@"Please check the log in F:\SampleFolder");
static async void M1M2()
{

    Method1();
    Method2();

}
static void SimpleThread()
{
    // Creating and initializing thread
    Thread thr = new Thread(MyThread) { Name = "T1"};
    Console.WriteLine($"Thread State: {thr.ThreadState}");
    thr.Start();
    Console.WriteLine($"Thread State: {thr.ThreadState}");
    thr.IsBackground = true;
    Console.WriteLine(Thread.CurrentThread.ManagedThreadId);
    thr.Join();
    Console.WriteLine("Main Thread Ends!!");
    Console.WriteLine($"Thread State: {thr.ThreadState}");
}

static void MyThread()
{
    Thread subThread = new Thread(() => { Console.WriteLine("\t\t A thread inside a thread. \n\t\t SubThread in Progress"); }) { Name="ST1"};
    Console.WriteLine($"\t Sub Thread State: {subThread.ThreadState}");
    subThread.Start();
    Console.WriteLine($"\t Sub Thread State: {subThread.ThreadState}");
    for (int c = 0; c <= 3; c++)
    {
        Console.WriteLine("MyThread is in progress!!");    
        
        Thread.Sleep(1000);

    }
    Console.WriteLine($"SubThread State: {subThread.ThreadState}");
    subThread.Join();
    Console.WriteLine("Joining back to main Thread...!!");
}

static async Task Method1()
{
    await Task.Run(() =>
    {
        for (int i = 0; i < 1000; i++)
        {
            Console.WriteLine($"M1-{i} Method 1");
        }
    });

}

static void Method2()
{
    for (int i = 0; i < 25; i++)
    {
        Console.WriteLine($"M2-{i} Method 2");
    }
}