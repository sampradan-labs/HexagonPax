using System.Diagnostics;

namespace PreThreadLongRunning
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }

        private void btnBlocking_Click(object sender, EventArgs e)
        {
               for (int i = 0; i < 100000; i++)
               {
                   Debug.WriteLine(i);
               }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A pop-up message");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //sbtnBlocking.PerformClick();
        }

        private async void btnAsync_Click(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                for (int i = 0; i < 100000; i++)
                {
                    Debug.WriteLine(i);
                }
            });
        }

        private void btnUsingThread_Click(object sender, EventArgs e)
        {
            Debug.WriteLine($"ThreadId: {Thread.CurrentThread.ManagedThreadId}");
            Thread t1 = new Thread(() => {
                for (int i = 0; i < 100000; i++)
                {
                    Debug.WriteLine(i);
                    Debug.WriteLine($"ThreadId: {Thread.CurrentThread.ManagedThreadId}");
                }
            });
            t1.Start();
        }
    }
}