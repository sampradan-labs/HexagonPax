﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
/*
 When performing blocking operations between the methods, 
 we should use asynchronous programming. 
 In scenarios where we have a fixed thread pool or 
 when we need vertical scalability in the application, 
 we use asynchronous programming.
 */
Console.WriteLine("=======================ASYNCHRONOUS PROGRAMMING============================");
await ExecuteAsyncFunctions();
Console.WriteLine("=======================MULTI-THREADING============================");
/*
 When we have independent functions performing independent tasks,
 we should use multithreading. One good example of this will be downloading multiple files 
 from multiple tabs in a browser. Each download will run in its own thread.
 */
ExecuteMultithreading();

#region Async code
/*
 We can see that all the operations are starting on the same thread with a number 1. 
But they are continuing their execution on different threads (4, 8, 11).
 */
static async Task ExecuteAsyncFunctions()
{
    var firstAsync = FirstAsync();
    var secondAsync = SecondAsync();
    var thirdAsync = ThirdAsync();
    await Task.WhenAll(firstAsync, secondAsync, thirdAsync);
}

static async Task FirstAsync()
{
    Console.WriteLine("First Async Method on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
    /*
     It’s happening because once the thread hits the awaiting operation in FirstAsync, 
     the thread is freed from that method and returned to the thread pool. 
     Once the operation is completed and the method has to continue, a new thread is assigned to it from a thread pool. 
     */
    await Task.Delay(1000);
    Console.WriteLine("First Async Method Continuation on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
}

static async Task SecondAsync()
{
    Console.WriteLine("Second Async Method on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
    await Task.Delay(1000);
    Console.WriteLine("Second Async Method Continuation on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
}

static async Task ThirdAsync()
{
    Console.WriteLine("Third Async Method on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
    await Task.Delay(1000);
    Console.WriteLine("Third Async Method Continuation on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
}
#endregion Async code

#region MultiThreading

static void ExecuteMultithreading()
{
    Thread t1 = new Thread(new ThreadStart(FirstMethod));
    Thread t2 = new Thread(new ThreadStart(SecondMethod));
    Thread t3 = new Thread(new ThreadStart(ThirdMethod));
    t1.Start();
    t2.Start();
    t3.Start();
}
static void FirstMethod()
{
    Console.WriteLine("First Method on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
    Thread.Sleep(1000);
    Console.WriteLine("First Method Continuation on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
}
static void SecondMethod()
{
    Console.WriteLine("Second Method on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
    Thread.Sleep(1000);
    Console.WriteLine("Second Method Continuation on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
}
static void ThirdMethod()
{
    Console.WriteLine("Third Method on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
    Thread.Sleep(1000);
    Console.WriteLine("Third Method Continuation on Thread with Id: " + Thread.CurrentThread.ManagedThreadId);
}
#endregion MultiThreading