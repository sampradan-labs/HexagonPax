﻿// See https://aka.ms/new-console-template for more information
using DI_Logger;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;

//DI_Technique_1();

public class Program
{
    private readonly ILogger<Program> _logger;
    private readonly IPersonRepository _personRepository;
    public Program(IPersonRepository pRepo, ILogger<Program> plogger)
    {
        this._personRepository = pRepo;
        this._logger = plogger;
    }
    public static void Main(string[] args) {
        var host = CreateHostBuilder(args).Build();
        host.Services.GetRequiredService<Program>().Run();
    }


    static IHostBuilder CreateHostBuilder(string[] args)
    {
        return Host.CreateDefaultBuilder(args)
                    .ConfigureServices(services =>
                                    {
                                        services.AddTransient<Program>();
                                        services.AddSingleton<IPersonRepository, PersonRepository>();
                                        services.AddScoped<PersonLogger>();
                                    });
    }

    public void Run()
    {
        _logger.LogInformation("Program is running");
        _personRepository.Works("Coding", true);
        _logger.LogInformation("Program execution completed");
    }

    static void DI_Technique_1()
    {
        //setup our DI
        var serviceProvider = new ServiceCollection()
            .AddLogging()
            .AddSingleton<IFooService, FooService>()
            .AddSingleton<IBarService, BarService>()
            .BuildServiceProvider();

        //configure console logging
        //serviceProvider
        //    .GetService<ILoggerFactory>()
        //    .AddConsole(LogLevel.Debug);

        var logger = serviceProvider.GetService<ILoggerFactory>()
            .CreateLogger<Program>();

        logger.LogDebug("Starting application");

        //do the actual work here
        var bar = serviceProvider.GetService<IBarService>();
        bar.DoSomeRealWork();
        logger.LogDebug("All done!");
    }
}
