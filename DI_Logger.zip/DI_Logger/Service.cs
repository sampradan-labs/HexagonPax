﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI_Logger
{
   public interface IPersonRepository
    {
        void Works(string task, bool isCompleted);
    }
    
    public class PersonRepository : IPersonRepository
    {
        private readonly PersonLogger logger;
        public PersonRepository(PersonLogger plogger)
        {
            logger = plogger;
        }

        public void Works(string task, bool isCompleted)
        {
            logger.LogTaskInfo(task, isCompleted);
        }
    }

    public class PersonLogger
    {
        private readonly ILogger<PersonLogger> _logger;
        public PersonLogger(ILogger<PersonLogger> logger)
        {
            _logger = logger;
        }
        public void LogTaskInfo(string taskName, bool isCompleted)
        {
            _logger.LogInformation($"LOG: {DateTime.Now}: Task name: {taskName}, Is task completed: {isCompleted}");
        }
    }

    
}
