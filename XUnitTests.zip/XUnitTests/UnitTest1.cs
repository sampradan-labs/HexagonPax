using Moq;
using System.Collections.Generic;
using Xunit;
using XunitSourceCode;

namespace XUnitTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test_AddMethod()
        {
            //Arrange
            int n1 = 100;
            int n2 = 200;
            int expected = 300;

            //Act
            int result = Add(n1, n2);

            //Assert
            Assert.Equal(expected, result);
            Assert.Equal<int>(expected, result);
        }

        private int Add(int n1, int n2)
        {
            return n1 + n2;
        }

        [Theory]
        [InlineData(100, 200, -100)]
        [InlineData(-100, -200, 100)]
        [InlineData(500, -200, 700)]
        public void Test_SubMethod(int n1, int n2, int expected)
        {

            //Act
            int result = Subtract(n1, n2);

            //Assert
            Assert.Equal(expected, result);
            Assert.Equal<int>(expected, result);
        }

        private int Subtract(int n1, int n2)
        {
            return n1 - n2;
        }

        [Fact(Skip = "To be done in Sprint 10")]
        [Trait("Sprint 10", "For Future SquareRoot Implementation")]
        public void Test_SquareRoot()
        {
            Assert.True(true);
        }

        public void NormalMethod() { }

        
        [Fact]
        public void Test_SimpleDI_InConstructor()
        {

            //Arrange
            Mock<IRepository> mockRepo = new Mock<IRepository>();
            //mockRepo.Setup((r) => r.GetItems()).Returns(() => new List<string>() { "s1","s2"});

            //Real call to create an object of Simple
            Simple objSimple = new Simple(mockRepo.Object);
            Assert.NotNull(objSimple);
            mockRepo.Verify();
        }

        /// <summary>
        /// Create an object of Simple passing mock.
        /// Call simpleobject.GetString();
        /// Verify that the above call made a call to mockRepo.GetItems
        /// </summary>
        [Fact]
        public void Test_Simple_MockGetItems()
        {
            //Arrange
            Mock<IRepository> mockRepo = new Mock<IRepository>();
            mockRepo.Setup((r) => r.GetItems()).Returns(() => new List<string>() { "s1", "s2" });

            //Create real object of Simple, but pass mockRepo as ctor param
            Simple objSlightlyComplex = new Simple(mockRepo.Object);
            objSlightlyComplex.GetStrings();
            mockRepo.Verify((IRepository r) => r.GetItems(), Times.Once);

        }
    }
}