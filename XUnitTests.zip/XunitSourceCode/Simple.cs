﻿using System.Text.RegularExpressions;

namespace XunitSourceCode
{
    public class Simple
    {
        public Simple()
        {

        }

        private IRepository _repo;
        public Simple(IRepository repo)
        {
            _repo = repo;
        }

        public List<string> GetStrings()
        {
            _repo.GetItems();
            return new List<string>() { "Eena", "Meena", "Deeka" };
        }

        public string GetDetail(string item)
        {
            return _repo.GetItems()
                        .Where(s => s == item)
                        .FirstOrDefault();
        }



        public bool IsValidAddress(string emailAddress)
        {
            Regex regex = new Regex(@"^[\w0-9._%+-]+@[\w0-9.-]+\.[\w]{2,6}$");
            return regex.IsMatch(emailAddress);
        }

    }
}