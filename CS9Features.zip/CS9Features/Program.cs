﻿// See https://aka.ms/new-console-template for more information

using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace CS9
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello C# 9");
            usingRecords();
            Console.WriteLine($"Cost of tickets for 2 visitors: {GetCost(2)}");
            Console.WriteLine($" Using Extensions with Patterns::Is A a letter or separator? :{'A'.IsLetterOrSeparator()}");
            Console.WriteLine("Using native ints with SkipLocals:");
            NativeTypes();
            unsafe
            {
                CallBacksWithPointers((num) => { Console.WriteLine($"Square of {num} = {num * num}"); },
                                        &WorkOnNum
                                      );
            }

            var printStatus = true;
            Print(printStatus ? 1 : 2); //by default calls long
            Print((short)(printStatus ? 1 : 2));    //calls short

            usingCoVariantTypes();

            UseStaticLambdas();

            //Use Covariant Return Types
            //***  the program below prints "C1.M" today, but would print "C2.M" under the proposed revision.
            //*** Due to this breaking change, Microsoft might consider not supporting covariant return types on implicit implementations.
            I1 i = new C2();
            Console.WriteLine(i.M());
            //

            #region Local Functions with Attributes

            [Obsolete("Attribute on local function")]
            void LocalFunction()
            {
                Console.WriteLine("Hello World!");
            }
            LocalFunction();

            #endregion Local Functions with Attributes

            UseModuleInitializers();
        }



        #region Records


        static void usingRecords()
        {
            //To assert equality, run time types must be same
            //Equality is value based
            Person teacher = new Teacher("Abdul", "Kalam", 3);
            Person student = new Student("Abdul", "Kalam", 3);
            Console.WriteLine($"Actual type of teacher: {teacher.GetType()}");
            Console.WriteLine($"Actual type of student: {student.GetType()}");
            Console.WriteLine($"Is teacher = student? {teacher == student}"); // output: False

            Student student2 = new Student("Abdul", "Kalam", 3);
            Console.WriteLine($"Actual type of student: {student.GetType()}");
            Console.WriteLine($"Actual type of student2: {student2.GetType()}");
            Console.WriteLine($"Is student = student2? {student2 == student}"); // output: True

            //using with
            //non-destructive mutation
            Student student3 = student2 with { FirstName = "Samprada" };
            Console.WriteLine($"Student3 Details: {student3.FirstName} | {student3.LastName} | {student3.Grade}");

        }

        public abstract record Person(string FirstName, string LastName);
        public record Teacher(string FirstName, string LastName, int Grade)
            : Person(FirstName, LastName);
        public record Student(string FirstName, string LastName, int Grade)
            : Person(FirstName, LastName);


        #endregion Records

        #region SkipLocalsInit & Native Ints
        [System.Runtime.CompilerServices.SkipLocalsInit]
        public static void NativeTypes()
        {
            unsafe
            {
                nint a = 1;
                System.IntPtr b = (IntPtr)1;
            }
        }
        #endregion SkipLocalsInit & Native Ints

        #region Function Pointers

        static void WorkOnNum(int i)
        {
            Console.WriteLine($"Double of {i} = {i * 2}");
        }

        unsafe static void CallBacksWithPointers(Action<int> a, delegate*<int, void> f)
        {
            a(42);
            f(42);
        }
        #endregion Function Pointers

        #region Simple Pattern
        public static decimal GetCost(int visitorCount) => visitorCount switch
        {
            1 => 12.0m,
            2 => 20.0m,
            3 => 27.0m,
            4 => 32.0m,
            0 => 0.0m,
            _ => throw new ArgumentException($"Not supported number of visitors: {visitorCount}", nameof(visitorCount)),
        };
        static string GetCalendarSeason(int month) => month switch
        {
            >= 3 and < 6 => "spring",
            >= 6 and < 9 => "summer",
            >= 9 and < 12 => "autumn",
            12 or (>= 1 and < 3) => "winter",
            _ => throw new ArgumentOutOfRangeException(nameof(month),
                            $"Unexpected month: {month}."),
        };
        #endregion Simple Pattern

        #region Target Typed Conditional Expressions
        private static void Print(long number)
        {
            Console.WriteLine("Calling Print Long: {0}: {1}", number.GetType(), number);
        }

        private static void Print(short number)
        {
            Console.WriteLine("Calling Print Short: {0}: {1}", number.GetType(), number);
        }
        #endregion Target Typed Conditional Expressions

        #region Covariant Return Types
        interface I1 { object M(); }
        class C1 : I1 { public object M() { return "C1.M"; } }
        class C2 : C1, I1 { public new string M() { return "C2.M"; } }
        static void usingCoVariantTypes()
        {
            I1 i = new C2();
            Console.WriteLine(i.M());
        }

        #endregion Covariant Return Types

        #region Static Anonymous Types

        private const string formattedText = "{0} C# was developed by Microsoft's Anders Hejlsberg in the year 2000.";
        static void DisplayText(Func<string, string> pfunc)
        {
            Console.WriteLine(pfunc("C# 9 new features."));
        }
        public static void UseStaticLambdas()
        {
            DisplayText(static text => string.Format(formattedText, text));
        }

        #endregion Static Anonymous Types

        #region Support for Enumerators in Foreach loop

        /*
         * In C# IEnumerator<T> doesn't have 'GetEnumerator()' method required by foreach loop. 
         * C# 9 allows to add it as an extension method and foreach loop recognizes it.
         */
        public static void UsingEnumeratorsWithForeach()
        {
            List<string> daysOfWeek = new List<string> { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };

            IEnumerator<string> daysOfWeekEnumerator = daysOfWeek.GetEnumerator();

            foreach (var country in daysOfWeekEnumerator)
            {
                Console.WriteLine($"{country} is a beautiful country");
            }
        }
        #endregion

        #region Using Discards

        public static void UsingDiscards()
        {
            Button button = new();
            button.Click += (_, _) => Console.WriteLine("Button clicked");
        }


        #endregion Using Discards

        #region Using Partial Extensions

        public static void UsingPartialExtensions()
        {
            Example ex = new();
            ex.A();
            Example.B();
            ex.C(out int i);
        }

        #endregion Using Partial Extensions

        #region Using Module Initializers

        public static void UseModuleInitializers()
        {
            XUnitTests tests = new();
            XUnitTests rests = new();
        }

        #endregion Using Module Initializers
    }

    #region Extensions
    public static class Extenstions
    {
        #region Patterns
        public static bool IsLetterOrSeparator(this char c) =>
             c is (>= 'a' and <= 'z') or (>= 'A' and <= 'Z') or '.' or ',';

        public static IEnumerator<T> GetEnumerator<T>(this IEnumerator<T> enumerator) => enumerator;
        #endregion Patterns
    }
    #endregion Extensions

    #region Covariant Return Types

    interface I1 { object M(); }
    class C1 : I1 { public object M() { return "C1.M"; } }
    class C2 : C1, I1 { public new string M() { return "C2.M"; } }

    #endregion Covariant Return Types

    #region Partial methods extensions

    partial class Example
    {
        // Other than void return type is allowed
        public partial int A();
        // Access modifiers are allowed
        public static partial void B();
        // Out params are allowed
        public partial void C(out int param);
    }
    partial class Example
    {
        public partial int A() => 0;
        public static partial void B() => Console.WriteLine("Static partial methods and access specifiers allowed");
        public partial void C(out int param)
        {
            param = 0;
        }
    }

    #endregion Partial methods extensions

    #region Module Initializers

    class XUnitTests
    {
        public XUnitTests()
        {
            Console.WriteLine($"Runs whenever instantiated, Value for Prefix is {Prefix}");
        }

        private static string Prefix;

        [ModuleInitializer]
        public static void OneTimeSetUp()
        {
            XUnitTests.Prefix = "HOME-";
            Console.WriteLine("This will run only once per module");
        }
    }

    #endregion Module Initializers
    class Button
    {
        public event EventHandler Click;
    }
}