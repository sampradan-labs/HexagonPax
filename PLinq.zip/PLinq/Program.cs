﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
//ParallelAndSerialQueries();
//ForcedParallelization();
DegreeOfParallelism();
static void ParallelAndSerialQueries()
{
#region Parallel LINQ
    // Source data that parallel and serial queries use.
    var source = Enumerable.Range(1, 100);

    // Perform parallel query
    var parallelQuery = from p in source.AsParallel()
                        where p.ToString().Contains("1")
                        select p;

    parallelQuery.ForAll((x) =>
    {
        Console.WriteLine("Parallel: " + x);
    });
#endregion Parallel LINQ

#region Serial LINQ
    // Perform serial query
    var serialQuery = from s in source
                      where s.ToString().Contains("1")
                      select s;
    serialQuery.All((x) =>
    {
        Console.WriteLine("Serial: " + x);
        return true;
    });
#endregion Serial LINQ
    Console.WriteLine("Press any key to exit...");
    Console.ReadLine();
}

static void ForcedParallelization()
{
    var source = Enumerable.Range(1, 100);

    // Perform parallel query. Use this option when you need high parallelization and have good resource capabilities
    var parallelQuery = from p in source.AsParallel().WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                        where p.ToString().Contains("1")
                        select new {Value= p, ProcessorId= Thread.GetCurrentProcessorId()};

    parallelQuery.ForAll((x) => {
        Console.WriteLine($"Value: {x.Value}, Processor Id: {x.ProcessorId}");
    });
}

static void DegreeOfParallelism()
{
    var source = Enumerable.Range(1, 100);

    // Perform parallel query. Use this option when you need high parallelization and have good resource capabilities
    var parallelQuery = from p in source.AsParallel().WithExecutionMode(ParallelExecutionMode.ForceParallelism).WithDegreeOfParallelism(7)
                        where p.ToString().Contains("1")
                        select new { Value = p, ProcessorId = Thread.GetCurrentProcessorId() };

    parallelQuery.ForAll((x) => {
        Console.WriteLine($"Value: {x.Value}, Processor Id: {x.ProcessorId}");
    });

}

